package com.cs_499.app_inventory_management

data class Item(
    var name: String? = null,
    var count: String? = null,
)
