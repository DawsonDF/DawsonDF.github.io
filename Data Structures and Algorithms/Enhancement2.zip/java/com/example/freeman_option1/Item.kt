package com.example.freeman_option1

class Item(@JvmField var name: String, @JvmField var count: String)
