package com.example.freeman_option1

/**
 * Item
 *
 * @property name
 * @property count
 * @constructor Create empty Item
 */
class Item(var name: String, var count: String)
